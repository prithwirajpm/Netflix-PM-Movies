import './App.css';
import Row from './components/Row';
function App() {
  return (
    <div className="App">
      <h1>netflix</h1>
      <Row />
    </div>
  );
}

export default App;
